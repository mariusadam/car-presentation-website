<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>BMW M4 Coupe modificat de G-Power</title>
<link href="style/style.css" rel="stylesheet" type="text/css" />

	<!-- Start WOWSlider.com HEAD section --> <!-- add to the <head> of your page -->
	<link rel="stylesheet" type="text/css" href="engine0/style.css" />
	<script type="text/javascript" src="engine0/jquery.js"></script>
	<!-- End WOWSlider.com HEAD section -->
	<!-- Start WOWSlider.com HEAD section --> <!-- add to the <head> of your page -->
	<link rel="stylesheet" type="text/css" href="engine0/style.css" />
	<!--script type="text/javascript" src="engine0/jquery.js"></script-->
	<!-- End WOWSlider.com HEAD section --></head>
<body>

<div class="outer">
	<div id="logo-bg">
		<h1>DRIVING PLEASURE</h1>
		<span class="tag"></span>
	</div>
	<div id="business"></div>
	<div class="clear"></div>
	<div id="bg">
		<div class="toplinks"><a href="index.php">Acasa</a></div><div class="sap">|</div>
		<div class="toplinks"><a href="masini_noi.php">Masini noi</a></div><div class="sap">|</div>
		<div class="toplinks"><a href="masini_sh.php">masini rulate</a></div><div class="sap">|</div>
		<div class="toplinks"><a href="contact.php">Contact</a></div><div class="sap">|</div>
		<?php
		//error_reporting (E_ALL ^ E_NOTICE);
session_start();
if (isset($_SESSION['user']))
    {?>
     <div class="toplinks"><a href="comm_logat.php">Comentarii</a></div><div class="sap">|</div>  
<?php
    }
	else
	{
?>
		<div class="toplinks"><a href="comm.php">Comentarii</a></div><div class="sap">|</div>
<?php
	}
	?>
		<div class="toplinks"><a href="admin.php">Scurt istoric</a></div>
	</div>
	<div class="clear"></div>
	<div id="outer2"><div class="inner_copy"></div>
		<div id="left-nav">
			<h2>Ultimele stiri
			</h2><div id="showcase">
				<div class="stxt-bg">
					<h3>Noul BMW iDrive</h3>
					<div class="smaltext"><a href="idrive.php"><img src="images/idrive.jpg" alt="" width="150" height="95" border="0"/></a>
						<div class="clear"></div>
						BMW a prezentat la CES 2015 coceptul viitorului sau sistem multimedia iDrive. 
						Acesta va fi capabil sa recunoasca gesturi si va avea si functie tactila.</div>
					<div style="clear:right; height:25px;">
					<span class="read-more"><a href="idrive.php">Citeste tot...</a></span></div>
				</div>
			</div>
			<div id="showcase">
				<div class="stxt-bg">
					<h3>BMW i3</h3>
					<div class="smaltext">
						<a href="i3.php"><img src="images/i3.jpg" alt="" width="150" height="95" border="0"/></a><br/>
						BMW i3 a fost imbunatatit cu ocazia inceputului de an. Modelul electric 
						poate parca fara sofer si poate chiar sa evite singur obstacolele.
				  </div>
				  <div style="clear:right; height:25px;"><span class="read-more"><a href="i3.php">Citeste tot...</a></span></div>
				</div>
			</div>
<div id="showcase">
<div class="stxt-bg">
<h3>BMW M4 Coupe modficat</h3>
<div class="smaltext"><a href="mpack.php"><img src="images/mpack.jpg" alt="" width="150" height="95" border="0"/></a>
	<div class="clear"></div>G-Power a pregatit un pachet special pentru BMW M4 Coupe. Modelul 
	german vine acum cu un look mult mai agresiv multumita unei caroserii de culoare neagra, 
	dar si datorita jantelor de 20 de inch HURRICANE RS.</div>
<div style="clear:right; height:25px;">
<span class="read-more"><a href="mpack.php">Citeste tot...</a></span></div>
</div>
</div>
</div>
<div id="content3">
<h2>BMW M4 Coupe modificat de G-Power</h2><br />
<div id="main">
 <img src="images/mpack_title.jpg">
 <p>Sub capota, BMW M4 Coupe vine alaturi de motorul cu sase cilindri de 3.0 litri TwinTurbo 
 capabil sa produca 431 de cai putere si 550 Nm. Mutumita unei electronice revizuite, motorul 
 propune acum 520 de cai intre 5.500 si 7.300 rpm si 700 Nm disponibili intre 1.850 si 5.500 rpm. </p>
<p>Modificarile aduse motoarelor BMW bi-turbo de 3 litri sunt efectuate direct in sistemul 
electronic de aprindere si evacuare al acestora, de la cei 413 CP ai modelelor de serie, 
variantele tunate sarind direct la 520 CP.Astfel, acceleratia de la 0 la 100 km/h se desfasoara 
in 3.9 secunde, cu 0.2 secunde mai rapid fata de versiunea de serie, in timp ce repriza 0 - 200 km/h 
are loc in 11.8 secunde. De asemenea, viteza maxima a crescut si ea de 280 km/h la 325 km/h 
transformand masina ta compacta sau coupe-ul M4 intr-un adevarat bolid cu o tinuta de invidiat.  </p>
<p>Pachetul tuning de baza este de 3.358 euro la care poti adauga in plus kitul de motorizare 
V-Max, de 3.451 euro, pentru un plus de viteza maxima impinsa la 325 km/h, jantele de otel 
forjat Hurricane RS de la Michelin, 7.998 euro, si sistemul de amortizare pe aer comprimat 
G-Power's GM4-RS de 2.427 euro.Costisitor, dar fara rival in ceea ce priveste senzatiile pe care le vei trai la volan!</p>
</div>
<div class="clear"></div>

	<!-- Start WOWSlider.com BODY section --> <!-- add to the <body> of your page -->
	<div id="wowslider-container0">
	<div class="ws_images"><ul>
		<li><img src="data0/images/mpack_4.jpg" alt="mpack_4" title="mpack_4" id="wows0_0"/></li>
		<li><img src="data0/images/mpack_5.jpg" alt="mpack_5" title="mpack_5" id="wows0_1"/></li>
		<li><img src="data0/images/mpack_1.jpg" alt="mpack_1" title="mpack_1" id="wows0_2"/></li>
		<li><a href="http://wowslider.com/vf"><img src="data0/images/mpack_2.jpg" alt="full screen slider" title="full screen slider" id="wows0_3"/></a></li>
		<li><img src="data0/images/mpack_3.jpg" alt="mpack_3" title="mpack_3" id="wows0_4"/></li>
	</ul></div>
	<div class="ws_bullets"><div>
		<a href="#wows0_0" title="mpack_4"><img src="data0/tooltips/mpack_4.jpg" alt="mpack_4"/>1</a>
		<a href="#wows0_1" title="mpack_5"><img src="data0/tooltips/mpack_5.jpg" alt="mpack_5"/>2</a>
		<a href="#wows0_2" title="mpack_1"><img src="data0/tooltips/mpack_1.jpg" alt="mpack_1"/>3</a>
		<a href="#wows0_3" title="full screen slider"><img src="data0/tooltips/mpack_2.jpg" alt="full screen slider"/>4</a>
		<a href="#wows0_4" title="mpack_3"><img src="data0/tooltips/mpack_3.jpg" alt="mpack_3"/>5</a>
	</div></div><span class="wsl"><a href="http://wowslider.com/vu">image carousel</a> by WOWSlider.com v7.4</span>
	<div class="ws_shadow"></div>
	</div>	
	<script type="text/javascript" src="engine0/wowslider.js"></script>
	<script type="text/javascript" src="engine0/script.js"></script>
	<!-- End WOWSlider.com BODY section --></div>

<div class="clear"></div>

<div class="footer"><a href="index.php">Acasa</a></div>
<div class="footer"><a href="masini_noi.php">Masini Noi</a></div>
<div class="footer"><a href="masini_sh.php">masini rulate</a></div>
<div class="footer"><a href="contact.php">Contact</a></div>
<?php
		//error_reporting (E_ALL ^ E_NOTICE);
//session_start();
if (isset($_SESSION['user']))
    {?>
     <div class="footer"><a href="comm_logat.php">Comentarii</a></div> 
<?php
    }
	else
	{
?>
		<div class="footer"><a href="comm.php">Comentarii</a></div>
<?php
	}
	?>
<div class="footer"><a href="admin.php">Scurt istoric</a></div>
<div class="clear"></div>
<div id="footer"><div class="fleft">� 2015 Marius Adam & Cristi Birla.Toate drepturile rezervate.</div>
<div class="fcenter">Design by MA &amp; CB ///coded by MA & CB</div></div>
</div>
</div>
</body>
</html>
