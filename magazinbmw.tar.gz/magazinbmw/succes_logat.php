<?php 
header("location: comm_logat.php");
?>