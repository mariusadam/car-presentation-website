<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>BMW X5 450CP xDrive50i Steptronic</title>
<link href="style/style.css" rel="stylesheet" type="text/css" />

	<!-- Start WOWSlider.com HEAD section --> <!-- add to the <head> of your page -->
	<link rel="stylesheet" type="text/css" href="engine0/style.css" />
	<script type="text/javascript" src="engine0/jquery.js"></script>
	<!-- End WOWSlider.com HEAD section --></head>
<body>

<div class="outer">
	<div id="logo-bg">
		<h1>DRIVING PLEASURE</h1>
		<span class="tag"></span>
	</div>
	<div id="business"></div>
	<div class="clear"></div>
	<div id="bg">
		<div class="toplinks"><a href="index.php">Acasa</a></div><div class="sap">|</div>
		<div class="toplinks"><a href="masini_noi.php">Masini noi</a></div><div class="sap">|</div>
		<div class="toplinks"><a href="masini_sh.php">masini rulate</a></div><div class="sap">|</div>
		<div class="toplinks"><a href="contact.php">Contact</a></div><div class="sap">|</div>
		<?php
		//error_reporting (E_ALL ^ E_NOTICE);
session_start();
if (isset($_SESSION['user']))
    {?>
     <div class="toplinks"><a href="comm_logat.php">Comentarii</a></div><div class="sap">|</div>  
<?php
    }
	else
	{
?>
		<div class="toplinks"><a href="comm.php">Comentarii</a></div><div class="sap">|</div>
<?php
	}
	?>
		<div class="toplinks"><a href="admin.php">Scurt istoric</a></div>
	</div>
	<div class="clear"></div>
	<div id="outer2"><div class="inner_copy"></div>
		<div id="left-nav">
			<h2>Ultimele stiri
			</h2><div id="showcase">
				<div class="stxt-bg">
					<h3>Noul BMW iDrive</h3>
					<div class="smaltext"><a href="idrive.php"><img src="images/idrive.jpg" alt="" width="150" height="95" border="0"/></a>
						<div class="clear"></div>
						BMW a prezentat la CES 2015 coceptul viitorului sau sistem multimedia iDrive.
						Acesta va fi capabil sa recunoasca gesturi si va avea si functie tactila.</div>
					<div style="clear:right; height:25px;">
					<span class="read-more"><a href="idrive.php">Citeste tot...</a></span></div>
				</div>
			</div>
			<div id="showcase">
				<div class="stxt-bg">
					<h3>BMW i3</h3>
					<div class="smaltext">
						<a href="i3.php"><img src="images/i3.jpg" alt="" width="150" height="95" border="0"/></a><br/>
						BMW i3 a fost imbunatatit cu ocazia inceputului de an. Modelul electric poate 
						parca fara sofer si poate chiar sa evite singur obstacolele.
				  </div>
				  <div style="clear:right; height:25px;"><span class="read-more"><a href="i3.php">Citeste tot...</a></span></div>
				</div>
			</div>
<div id="showcase">
<div class="stxt-bg">
<h3>BMW M4 Coupe modficat</h3>
<div class="smaltext"><a href="mpack.php"><img src="images/mpack.jpg" alt="" width="150" height="95" border="0"/></a>
	<div class="clear"></div>G-Power a pregatit un pachet special pentru BMW M4 Coupe. 
	Modelul german vine acum cu un look mult mai agresiv multumita unei caroserii de culoare neagra,
	dar si datorita jantelor de 20 de inch HURRICANE RS.</div>
<div style="clear:right; height:25px;">
<span class="read-more"><a href="mpack.php">Citeste tot...</a></span></div>
</div>
</div>
</div>
<div id="content3">
<h2>BMW X5 450CP xDrive50i Steptronic</h2> <br />
<div id="main">
 <P><img src="images/n23_pret.jpg"></P>
 <p> <img src="images/n23_date.jpg" ></p>
 <p>&nbsp&nbsp&nbsp&nbsp BMW X5 are deja 15 ani de cariera. 15 ani de c�nd BMW a lansat ceea 
 ce a numit la acea vreme "SAV". Adica Sport Activity Vehicle. Prima generatie a venit la
 finalul lui 1999 si era primul SUV produs de marca bavareza. P�na �n acel moment, BMW nu
 se aventurase pe terenul automobilelor din acest segment, dar c�nd a decis sa faca pasul
 a reusit sa creeze un SUV cu adevarate calitati dinamice care �si pastra spiritul sportiv
 pe sosea, dar putea negocia si drumuri dificile neasfaltate. Prima generatie avea sub capota
 motoare mari, cu sase si opt cilindri, si un singur diesel. De atunci si p�na astazi,
 lucrurile s-au schimbat radical. 
 <br />&nbsp&nbsp&nbsp&nbsp 
 Noul X5 a crescut �n dimensuni fata de generatia anterioara. Este acum ceva mai masiv,
 iar asta se traduce si printr-un spatiu interior mai generos. �n fata, lucrurile sunt 
 perfecte. Evem spatiu mai mult dec�t suficient pentru cei doi ocupanti ai primului r�nd,
 iar scaunele optionale confort sunt sublime. Ce-i drept, acestea costa 2.380 euro, 
 dar daca aveti de g�nd sa folositi masina la drumuri lungi merita fiecare cent. Sunt
 extrem de confortabile, pot fi reglate electric p�na la cele mai mici amanunte, 
 un adevarat rasfat pentru cel de la volan si �nsotitorul sau.
 <br />&nbsp&nbsp&nbsp&nbsp 
 BMW X5 este unul dintre acele automobile pe care poti sa le recunosti instant pe 
 strada. Si acest lucru nu se datoreaza unui design extrem de spectaculos, ci unei
 identitati bine structurate. De la prima si p�na la a treia si actuala generatie,
 X5 a evoluat din punct de vedere al designului, dar nu si-a speriat niciodata
 clientii prin artificii inutile.
 <br />&nbsp&nbsp&nbsp&nbsp 
 Noua generatie poate fi recunoscuta usor datorita blocurilor optice frontale care 
 se lipesc acum de faimoasa grila BMW. �n plus, BMW te lasa sa �ti alegi stilul
 propun�nd doua pachete de design exterior. Cel al modelului de test se numeste 
 Pure Experience si costa 2.000 euro �n plus fata de varianta standard. 
 Alternativele sunt Pure Excellence, care merge pe o linie mai eleganta, sau
 sportivul M Pack. Orice ai alege, BMW X5 ram�ne o prezenta impunatoare. Nu 
 putem spune despre el ca este un automobil frumos, este �nsa unul cu o identitate bine stabilita.</p>
	<!-- Start WOWSlider.com BODY section --> <!-- add to the <body> of your page -->
	</div>
<div class="clear"></div>
</div><br>
<div id="wowslider-container0">
    <img src="images/galerie_logo.jpg" >
	<div class="ws_images"><ul>
		<li><img src="data0/images/n23_9.jpg" alt="n23_9" title="n23_9" id="wows0_0"/></li>
		<li><img src="data0/images/n23_10.jpg" alt="n23_10" title="n23_10" id="wows0_1"/></li>
		<li><img src="data0/images/n23_1.jpg" alt="n23_1" title="n23_1" id="wows0_2"/></li>
		<li><img src="data0/images/n23_2.jpg" alt="n23_2" title="n23_2" id="wows0_3"/></li>
		<li><img src="data0/images/n23_3.jpg" alt="n23_3" title="n23_3" id="wows0_4"/></li>
		<li><img src="data0/images/n23_4.jpg" alt="n23_4" title="n23_4" id="wows0_5"/></li>
		<li><img src="data0/images/n23_5.jpg" alt="n23_5" title="n23_5" id="wows0_6"/></li>
		<li><img src="data0/images/n23_6.jpg" alt="n23_6" title="n23_6" id="wows0_7"/></li>
		<li><a href="http://wowslider.com/vf"><img src="data0/images/n23_7.jpg" alt="full screen slider" title="full screen slider" id="wows0_8"/></a></li>
		<li><img src="data0/images/n23_8.jpg" alt="n23_8" title="n23_8" id="wows0_9"/></li>
	</ul></div>
	<div class="ws_bullets"><div>
		<a href="#wows0_0" title="n23_9"><img src="data0/tooltips/n23_9.jpg" alt="n23_9"/>1</a>
		<a href="#wows0_1" title="n23_10"><img src="data0/tooltips/n23_10.jpg" alt="n23_10"/>2</a>
		<a href="#wows0_2" title="n23_1"><img src="data0/tooltips/n23_1.jpg" alt="n23_1"/>3</a>
		<a href="#wows0_3" title="n23_2"><img src="data0/tooltips/n23_2.jpg" alt="n23_2"/>4</a>
		<a href="#wows0_4" title="n23_3"><img src="data0/tooltips/n23_3.jpg" alt="n23_3"/>5</a>
		<a href="#wows0_5" title="n23_4"><img src="data0/tooltips/n23_4.jpg" alt="n23_4"/>6</a>
		<a href="#wows0_6" title="n23_5"><img src="data0/tooltips/n23_5.jpg" alt="n23_5"/>7</a>
		<a href="#wows0_7" title="n23_6"><img src="data0/tooltips/n23_6.jpg" alt="n23_6"/>8</a>
		<a href="#wows0_8" title="full screen slider"><img src="data0/tooltips/n23_7.jpg" alt="full screen slider"/>9</a>
		<a href="#wows0_9" title="n23_8"><img src="data0/tooltips/n23_8.jpg" alt="n23_8"/>10</a>
	</div></div><span class="wsl"><a href="http://wowslider.com/vu">image carousel</a> by WOWSlider.com v7.4</span>
	<div class="ws_shadow"></div>
	</div>	
	<script type="text/javascript" src="engine0/wowslider.js"></script>
	<script type="text/javascript" src="engine0/script.js"></script>
	<!-- End WOWSlider.com BODY section -->
<div class="clear"></div>

<div class="footer"><a href="index.php">Acasa</a></div>
<div class="footer"><a href="masini_noi.php">Masini Noi</a></div>
<div class="footer"><a href="masini_sh.php">masini rulate</a></div>
<div class="footer"><a href="contact.php">Contact</a></div>
<?php
		//error_reporting (E_ALL ^ E_NOTICE);
//session_start();
if (isset($_SESSION['user']))
    {?>
     <div class="footer"><a href="comm_logat.php">Comentarii</a></div> 
<?php
    }
	else
	{
?>
		<div class="footer"><a href="comm.php">Comentarii</a></div>
<?php
	}
	?>
<div class="footer"><a href="admin.php">Scurt istoric</a></div>
<div class="clear"></div>
<div id="footer"><div class="fleft">� 2015 Marius Adam & Cristi Birla.Toate drepturile rezervate.</div>
<div class="fcenter">Design by MA &amp; CB ///coded by MA & CB</div></div>
</div>
</div>
</body>
</html>
