<?php 
header("location: comm.php");
?>